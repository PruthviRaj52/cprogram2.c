#include<stdio.h>
void main()
{
	int a,b,c;
	clrscr();
	scanf("%d%d%d",&a,&b,&c);
	printf("c<a && c<b,res= %d",c<a&&c<b);
	getch();
}