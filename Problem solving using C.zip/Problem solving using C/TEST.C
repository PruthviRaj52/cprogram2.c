#include<stdio.h>
void main()
{
	int a=3,b=5,sum;
	clrscr();
	sum=a+b;
	printf("a=%d b=%d Result=%d",sum,b,a);
}
