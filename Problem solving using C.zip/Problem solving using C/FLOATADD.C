#include<stdio.h>
int main() 
{ 
	int number;
	float amount;
	number = 100;
	amount = 30.75 + 75.35;
	printf("%d\n",number);
	printf("%5.2f",amount);
	return 0;
}