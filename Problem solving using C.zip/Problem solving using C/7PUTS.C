#include<stdio.h>
void main()
{
	char ch;
	clrscr();
	printf("Enter a character: ");
	ch=getchar();
	puts("you entered: ");
	putchar(ch);
	getch();
}
