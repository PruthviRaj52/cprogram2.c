void main()
{
	int n;
	clrscr();
	printf("\n Enter any number : ");
	scanf("%d",&n); 
	if(n%2==0)
		printf("\n The %d is Even ",n);
	else
		printf("\n The %d is Odd ",n);
	getch();
}
