#include<stdio.h>
void main()
{
	int a=7,b=3,c=8,addition,multiplication,subraction,division;
	int modulus, equivalent,not_equivalent,greater,lesser;
	int greater_than_and_equal,lesser_than_and_equal;
