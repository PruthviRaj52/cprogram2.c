#include <stdio.h>
void main()
{
	int i;
    for(i=65;i<91;i++)
		printf( "%c", (char)i );
    printf("\n");
    for(i=97;i<123;i++)
		printf( "%c", (char)i );
}