#include<stdio.h>
void main()
{
	char s[30];
	clrscr();
	printf("Enter the string= ");
	gets(s);
	printf("\n You entered :%s",s);
	getch();
}
