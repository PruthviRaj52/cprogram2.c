#include<stdio.h>
void main()
{
	int x=22,y=7;
	float z=x/y;
	clrscr();
	printf("\n z=%f ",z);
	getch();
}
