int x=10,y=4;
float z= (float)x/y;
printf("\n z=%f \n",z);
