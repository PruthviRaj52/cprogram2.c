#include <stdio.h>
int main() 
{
	int testInteger;
	clrscr();
	printf("Enter an integer: ");
	scanf("%d",&testInteger);
	printf("Number = %d",testInteger);
	getch();
	return 0;
}

//program for scanf statement
#include <stdio.h>
int main() 
{
	int testInteger;
	clrscr();
	printf("Enter an integer: ");
	scanf("%d",&testInteger);
	printf("Number = %d",testInteger);
	getch();
	return 0;
}