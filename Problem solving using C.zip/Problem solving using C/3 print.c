#include <stdio.h>
int main()
{
	int testInteger = 5;
	printf("Number = %d", testInteger);
	getch();
	return 0;
}