int sum=17, count=5;
double mean;
mean=(double)sum/count;
printf("\n mean=%f \n",mean);