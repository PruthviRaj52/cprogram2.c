#include<stdio.h>
void main()
{
	int a=0,result;
	clrscr();
	result=(~a);
	printf("\n ~a:%d",result);
	getch();
}