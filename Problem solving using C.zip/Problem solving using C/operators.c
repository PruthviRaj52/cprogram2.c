#include<stdio.>
void main()
{
	int a=7, b=3, c;
	printf("\n Arithmetic Operations");
	printf("\n a+b=%d",c=a+b);
	/*printf("\n a+b=%d",c=a+b);
	printf("\n a+b=%d",c=a+b);
	printf("\n a+b=%d",c=a+b);
	printf("\n a+b=%d",c=a+b);*/
	getch();
}
	
	