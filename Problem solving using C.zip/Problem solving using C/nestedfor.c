void main()
{
	int i,j;
	for(i=1;i<=2;i++)
	{
		for(j=1;j<=2;j++)
		{
			printf("%d%d",i,j);
		}
	}
	getch();
}
